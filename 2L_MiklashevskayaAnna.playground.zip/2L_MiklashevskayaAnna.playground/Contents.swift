//1 написать программу которая определяет четное число или нет
let number: Int = 1
if number % 2 == 0 {
    print("Число четное")
} else{
    print ("Число нечетное")
}

//2  Написать функцию, которая определяет, делится ли число без остатка на 3
let numb: Int = 1
if numb % 3 == 0 {
    print("Число делится на 3 без остатка")
} else{
    print ("Число не делится на 3 без остатка")
}

//3 Создать возрастающий массив из 100 чисел.
import UIKit
var values = Array(1...100)
print(values)

//4  Удалить из этого массива все четные числа и все числа, которые не делятся на 3
var DeleteNumbers = values.filter {$0 % 2 != 0 && $0 % 3 == 0}
print(DeleteNumbers)

//5 * Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 50 элементов.

func fibonacci (n: Int) -> (Decimal) {
    if (n<3) {
        return 1
    } else {
        var z1 : Decimal = 1, z2 : Decimal = 1, z:Decimal
        for _ in 3...n {
            z = z1+z2
            z1 = z2
            z2 = z
        }
        return z2
    }
}

var fibArray = [Decimal]()
fibArray.append(0)
var n  = 100
for i in 1...n {
    fibArray.append(fibonacci(n: i))
}
print(fibArray)
